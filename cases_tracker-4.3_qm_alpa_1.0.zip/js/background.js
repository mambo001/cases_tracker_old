chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.contentScriptQuery == "queryPrice") {
          console.log("Query: queryPrice")
          var url = "https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=read";
          fetch(url)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
          return true;  // Will respond asynchronously.
        } else if (request.contentScriptQuery == "consultedBucketQuery"){
            
          console.log("Query: consultedBucketQuery")
            
          // Consulted Bucket Query
          const urlConsulted = "https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=read&tab=Consulted%20Bucket";
          fetch(urlConsulted)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
          return true;  // Will respond asynchronously.

        } else if (request.contentScriptQuery == "submittedBucketQuery"){
            
          console.log("Query: submittedBucketQuery")
            
          // Submitted Bucket Query
          const urlSubmitted = "https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=read&tab=All%20Cases";
          fetch(urlSubmitted)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
          return true;  // Will respond asynchronously.
          
        } else if (request.contentScriptQuery == "QMPrioDumpQuery"){
            
          console.log("Query: QMPrioDumpQuery")
            
          // Submitted Bucket Query
          const QMPrioURL = `https://script.google.com/a/macros/google.com/s/AKfycbwey7b36eX2Er8jnJXi04UhW01-U2LONfM_YoOz6LSI/dev?action=read&tab=QM%20-%20Prio`;
        //   const urlSubmitted = "https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=read&tab=All%20Cases";
          fetch(QMPrioURL)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
          return true;  // Will respond asynchronously.
          
        } else if (request.contentScriptQuery == "submitQMQuery"){
                  // QM Endpoint
          const QMSubmitURL = `https://script.google.com/a/macros/google.com/s/AKfycbwey7b36eX2Er8jnJXi04UhW01-U2LONfM_YoOz6LSI/dev?flag=1`;
            
          fetch(QMSubmitURL,{
              method: 'POST',
              cache: 'no-cache',
              redirect: 'follow',
              body: JSON.stringify(request.postData)
          })
          .then(response => response.json())
          .then(data => sendResponse(data))
          .catch(error => sendResponse({response: 'error'}))
          return true;  // Will respond asynchronously.

        } else if (request.contentScriptQuery == "templatedBucketQuery"){
            console.log("Query: templatedBucketQuery")
                
              // Template Bucket Query
            const urlTemplate = `https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=read&tab=Template%20Bucket`;
            fetch(urlTemplate)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
              
        } else if (request.contentScriptQuery == "finishedCaseQuery"){
            // https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=insert&
            
            console.log("Query: finishedCaseQuery")
                
              // Finished Case Query
            const urlTemplate = `https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=insert&${request.caseData}`;
            fetch(urlTemplate)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
        } else if (request.contentScriptQuery == "submitScrapedCasesQuery"){
            console.log("Query: submitScrapedCasesQuery")
            
            const url = `https://script.google.com/a/google.com/macros/s/AKfycbxzRc1TpiQGRNWZWbbv9XqMJuuPuQgvxO-3ywPZbeY/dev?ldap=${request.ldap}`;
            
            fetch(url,{
              method: 'POST',
              cache: 'no-cache',
              redirect: 'follow',
              body: JSON.stringify(request.data)
            //   first half to array element from array data
            })
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
            
        } else if (request.contentScriptQuery == "consultCaseQuery"){
            
            console.log("Query: consultCaseQuery")
            
            const url = `https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=insert&tab=Consulted%20Bucket&${request.parameters}`;
            
            fetch(url)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
        } else if (request.contentScriptQuery == "consultedCaseAssignedQuery"){
            console.log("Query: consultedCaseAssignedQuery")
            
            const url = `https://script.google.com/a/google.com/macros/s/AKfycbzjhgxDHp_UlzjHnsguxTpt-FOTqPkAPGnFVGJeXUw/dev?action=delete&tab=Consulted%20Bucket&id=${request.parameters}`;
            
            fetch(url)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
              
        } else if (request.contentScriptQuery == "saveTemplateQuery"){
            console.log("Query: saveTemplateQuery")
            
            const url = `https://script.google.com/a/google.com/macros/s/AKfycbw6tEzDQXsxVzmGOSNnfL9yZrCSJKxSLNxq7QriThKh/dev?action=insert&tab=Template%20Bucket&${request.parameters}`;
            
            fetch(url)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
        } else if (request.contentScriptQuery == "SPRARQuery"){
            console.log("Query: SPRARQuery")
            
            const url = `https://script.google.com/a/macros/google.com/s/AKfycbwey7b36eX2Er8jnJXi04UhW01-U2LONfM_YoOz6LSI/dev?action=read&tab=SPR-AR`;
            
            // https://script.google.com/a/macros/google.com/s/AKfycbwey7b36eX2Er8jnJXi04UhW01-U2LONfM_YoOz6LSI/dev?action=read
            
            
            fetch(url)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
              
              
        } else if (request.contentScriptQuery == "changeCaseStatesSPRQuery"){
            console.log("Query: changeCaseStatesSPRQuery");
            
            const { caseID, status } = request.parameters;
            // const stringifiedCaseData = JSON.stringify(data);
            const url = `https://script.google.com/a/macros/google.com/s/AKfycbwey7b36eX2Er8jnJXi04UhW01-U2LONfM_YoOz6LSI/dev?action=updateCaseStatus&caseID=${caseID}&caseStatus=${status}`;
            
            // https://script.google.com/a/macros/google.com/s/AKfycbwey7b36eX2Er8jnJXi04UhW01-U2LONfM_YoOz6LSI/dev?action=read
            
            
            fetch(url)
              .then(response => response.json())
              .then(data => sendResponse(data))
              .catch(error => sendResponse({response: 'error'}))
              return true;  // Will respond asynchronously.
        }
    }
);